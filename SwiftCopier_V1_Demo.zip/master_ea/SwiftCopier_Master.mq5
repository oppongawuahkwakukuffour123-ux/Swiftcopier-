#property strict
#property version "1.00"

input string API_URL = "https://YOUR-SWIFT-COPIER.onrender.com/api/v1/trade";
input string API_KEY = "CHANGE_MASTER_KEY";
input string MASTER_ID = "MASTER_DEMO_001";

string JsonEscape(string s)
{
   StringReplace(s, "\\", "\\\\");
   StringReplace(s, "\"", "\\\"");
   return s;
}

void SendSignal(string json)
{
   string headers =
      "Content-Type: application/json\r\n"
      "Authorization: Bearer " + API_KEY + "\r\n";

   char data[];
   char response[];
   string response_headers;

   StringToCharArray(json, data);
   int data_size = ArraySize(data);
   if(data_size > 0 && data[data_size-1] == 0)
      data_size--;

   ResetLastError();

   int code = WebRequest(
      "POST",
      API_URL,
      headers,
      5000,
      data,
      data_size,
      response,
      response_headers
   );

   if(code == -1)
      Print("SwiftCopier Master WebRequest error: ", GetLastError());
   else
      Print("SwiftCopier Master HTTP: ", code);
}

void OnTradeTransaction(
   const MqlTradeTransaction &trans,
   const MqlTradeRequest &request,
   const MqlTradeResult &result)
{
   if(trans.type != TRADE_TRANSACTION_DEAL_ADD)
      return;

   ulong deal = trans.deal;
   if(deal == 0 || !HistoryDealSelect(deal))
      return;

   long deal_type = HistoryDealGetInteger(deal, DEAL_TYPE);
   long entry = HistoryDealGetInteger(deal, DEAL_ENTRY);

   string side = "UNKNOWN";
   if(deal_type == DEAL_TYPE_BUY) side = "BUY";
   if(deal_type == DEAL_TYPE_SELL) side = "SELL";

   string event = "OTHER";
   if(entry == DEAL_ENTRY_IN) event = "OPEN";
   else if(entry == DEAL_ENTRY_OUT) event = "CLOSE";
   else if(entry == DEAL_ENTRY_INOUT) event = "REVERSE";
   else if(entry == DEAL_ENTRY_OUT_BY) event = "CLOSE_BY";

   string symbol = HistoryDealGetString(deal, DEAL_SYMBOL);
   double volume = HistoryDealGetDouble(deal, DEAL_VOLUME);
   double price = HistoryDealGetDouble(deal, DEAL_PRICE);
   long position_id = HistoryDealGetInteger(deal, DEAL_POSITION_ID);

   double sl = 0.0;
   double tp = 0.0;

   if(position_id > 0 && PositionSelectByTicket((ulong)position_id))
   {
      sl = PositionGetDouble(POSITION_SL);
      tp = PositionGetDouble(POSITION_TP);
   }

   string json =
      "{"
      "\"master_id\":\"" + JsonEscape(MASTER_ID) + "\","
      "\"position_id\":\"" + LongToString(position_id) + "\","
      "\"event\":\"" + event + "\","
      "\"side\":\"" + side + "\","
      "\"symbol\":\"" + JsonEscape(symbol) + "\","
      "\"volume\":" + DoubleToString(volume, 8) + ","
      "\"price\":" + DoubleToString(price, _Digits) + ","
      "\"sl\":" + DoubleToString(sl, _Digits) + ","
      "\"tp\":" + DoubleToString(tp, _Digits) +
      "}";

   SendSignal(json);
}
