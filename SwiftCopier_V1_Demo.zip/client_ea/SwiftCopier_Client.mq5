#property strict
#property version "1.00"

#include <Trade/Trade.mqh>

input string API_URL = "https://YOUR-SWIFT-COPIER.onrender.com/api/v1/signals";
input string API_KEY = "CHANGE_CLIENT_KEY";
input double LOT_MULTIPLIER = 1.0;
input ulong MAGIC_NUMBER = 870001;
input int POLL_SECONDS = 2;

CTrade trade;
long last_signal_id = 0;

string Extract(string json, string key)
{
   string needle = "\"" + key + "\":";
   int p = StringFind(json, needle);
   if(p < 0) return "";

   p += StringLen(needle);

   while(p < StringLen(json) && StringGetCharacter(json,p) == ' ')
      p++;

   if(p < StringLen(json) && StringGetCharacter(json,p) == '"')
   {
      p++;
      int e = StringFind(json, "\"", p);
      if(e < 0) return "";
      return StringSubstr(json, p, e-p);
   }

   int e = p;
   while(e < StringLen(json))
   {
      ushort c = StringGetCharacter(json,e);
      if(c == ',' || c == '}') break;
      e++;
   }
   return StringTrim(StringSubstr(json,p,e-p));
}

double NormalizeVolume(string symbol, double volume)
{
   double minv = SymbolInfoDouble(symbol, SYMBOL_VOLUME_MIN);
   double maxv = SymbolInfoDouble(symbol, SYMBOL_VOLUME_MAX);
   double step = SymbolInfoDouble(symbol, SYMBOL_VOLUME_STEP);

   if(step <= 0) step = minv;

   volume *= LOT_MULTIPLIER;
   volume = MathMax(minv, MathMin(maxv, volume));
   volume = MathFloor(volume / step) * step;

   int digits = 0;
   double x = step;
   while(x < 1.0 && digits < 8)
   {
      x *= 10.0;
      digits++;
   }

   return NormalizeDouble(volume, digits);
}

bool ExecuteSignal(string signal)
{
   long id = (long)StringToInteger(Extract(signal,"id"));
   if(id <= last_signal_id)
      return true;

   string event = Extract(signal,"event");
   string side = Extract(signal,"side");
   string symbol = Extract(signal,"symbol");

   double volume = StringToDouble(Extract(signal,"volume"));
   double sl = StringToDouble(Extract(signal,"sl"));
   double tp = StringToDouble(Extract(signal,"tp"));

   if(!SymbolSelect(symbol,true))
   {
      Print("SwiftCopier: Cannot select symbol ", symbol);
      return false;
   }

   trade.SetExpertMagicNumber(MAGIC_NUMBER);

   if(event == "OPEN")
   {
      volume = NormalizeVolume(symbol, volume);
      bool ok = false;

      if(side == "BUY")
         ok = trade.Buy(volume, symbol, 0.0, sl, tp, "SwiftCopier");
      else if(side == "SELL")
         ok = trade.Sell(volume, symbol, 0.0, sl, tp, "SwiftCopier");

      if(!ok)
      {
         Print("SwiftCopier trade failed: ",
               trade.ResultRetcode(),
               " ",
               trade.ResultRetcodeDescription());
         return false;
      }

      Print("SwiftCopier copied signal #", id);
      last_signal_id = id;
      GlobalVariableSet("SWIFT_LAST_SIGNAL", (double)last_signal_id);
      return true;
   }

   // CLOSE/REVERSE handling is deliberately disabled in V1.
   // We will add position mapping after open-copy testing succeeds.
   last_signal_id = id;
   GlobalVariableSet("SWIFT_LAST_SIGNAL", (double)last_signal_id);
   return true;
}

void Poll()
{
   string headers = "Authorization: Bearer " + API_KEY + "\r\n";
   char data[];
   char response[];
   string response_headers;

   ResetLastError();

   int code = WebRequest(
      "GET",
      API_URL + "?after_id=" + LongToString(last_signal_id),
      headers,
      5000,
      data,
      0,
      response,
      response_headers
   );

   if(code == -1)
   {
      Print("SwiftCopier Client WebRequest error: ", GetLastError());
      return;
   }

   string body = CharArrayToString(response);

   int start = 0;
   while(true)
   {
      int p = StringFind(body, "{\"id\":", start);
      if(p < 0) break;

      int end = StringFind(body, "}", p);
      if(end < 0) break;

      string signal = StringSubstr(body, p, end-p+1);
      ExecuteSignal(signal);
      start = end + 1;
   }
}

int OnInit()
{
   trade.SetExpertMagicNumber(MAGIC_NUMBER);

   if(GlobalVariableCheck("SWIFT_LAST_SIGNAL"))
      last_signal_id = (long)GlobalVariableGet("SWIFT_LAST_SIGNAL");

   EventSetTimer(MathMax(1,POLL_SECONDS));
   Print("SwiftCopier Client started. Last signal = ", last_signal_id);
   return INIT_SUCCEEDED;
}

void OnDeinit(const int reason)
{
   EventKillTimer();
}

void OnTimer()
{
   Poll();
}
